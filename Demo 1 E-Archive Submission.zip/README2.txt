Due to integration with a database happening almost immediately, unit tests were run manually as the code was being developed.
Therefore, there is information on how to manually run integration tests in README3.txt.
The tests are manual for integration tests due to the code being heavily dependent on the user-interface.