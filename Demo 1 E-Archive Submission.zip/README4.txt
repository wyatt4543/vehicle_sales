The only data collection that exists are scripts connected to the purchase web page and login pages.
There are no scripts made specifically for data collection.

to test the data collection you follow the steps in README1.txt to get the website running.
To see the collected data sign in using either of these accounts (capitalization matters):
username: Admin
password: 1qart2QART!

username: j400
password: 1234

The homepage is the page with a collection of vehicles listed in a catalog.
To sign into an account, click the sign in button on the homepage and enter information for either account.
To see a user's information login to a non-admin account. Go to the homepage and click on the "User" button.
Then, click the "Mail & Payment Info" button. The user's information should be displayed including NULL information.

To see the purchases logout of the user and login to the admin account. On the homepage, click the "Manager" button.
There should be various buttons.
The "Manage User Information" button allows you to search even more information on specific users.
The "Check Sales Report" button allows you to see the sales that have been made.

To collect even more sales information you can complete a purchase when logged in.