to run the code install python at: https://www.python.org/

then in the cmd prompt run:
pip install Flask mysql-connector-python bcrypt secure-smtplib

Double click the python file, or run the python file from the python IDLE
afterwards connect to the host found in the console from a web browser:
my console says: * Running on http://127.0.0.1:5000

Note: the email function may not work due to it requiring a new app password for each new device in app.py on the line that says "server.login(email, "qewutidqrqlfokjh")"
